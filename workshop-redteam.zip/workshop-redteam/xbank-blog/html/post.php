<?php
    include_once("database.php");

    if (isset($_GET['id']) && $_GET['id'] != "") {
        try {
            $conn = connectToDb();
            $post = fetchPostById($conn, $_GET['id']);
            $conn->close();
        } catch (Exception $e) {
            die("Something went wrong.");
        }
    }
    else {
        die(header("Location: /"));
    }
?>
<head>
<!-- For UX/UI only -->
<meta charset="utf-8">
<link rel="stylesheet" href="/assets/css/bootstrap.min.css">
<style>
    .center-screen {
        position: fixed;
        top: 40%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
</style>
</head>
<body class="bg-dark">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="container-fluid">
<a class="navbar-brand" href="#">Internal Blogs</a>
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link active" aria-current="page" href="#">Dashboard</a>
</li></ul></div></div>
</nav>
<div class='cover-container d-flex w-100 h-100 p-3 mx-auto flex-column'>
<div class="my-3 p-4 bg-body rounded shadow-sm w-50 center-screen">
<div>
<?php if (isset($post)) { ?>
<h6 class="border-bottom pb-2 mb-0"><?= $post['title'] ?></h6>
<div class="d-flex text-body-secondary pt-3">
<svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"/><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>
<p class="pb-3 mb-0 small lh-sm border-bottom">
<strong class="d-block text-gray-dark">@<?= $post['author']?></strong>
<?=$post['content']?>
</p>
</div>
<?php } else { ?>
<h6 class='my-0 text-center'>Post not found.</h6>
<?php } ?>
</div></div></div>
</body>