<?php
    function connectToDb() {
        $conn = new mysqli(
            "localhost", 
            "admin", 
            "cca6e26e1b11b38cdfcd42829334dfd7", 
            "blog"
        );

        return $conn;
    }

    function decodePost($post) {
        $post["title"] = base64_decode($post["title"]);
        $post["content"] = base64_decode($post["content"]);

        return $post;
    }

    function fetchPostById($conn, $id) {
        $sql = "SELECT * FROM posts WHERE id=" . $id;
        $result = $conn->query($sql);

        $post = [];
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $post = decodePost($row);
            }
            return $post;
        }
    }

    function fetchAllPosts($conn) {
        $sql = "SELECT * FROM posts";
        $result = $conn->query($sql);

        $posts = [];
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $posts[] = decodePost($row);
            }
        }

        return $posts;
    }
?>