<?php 
    $json = file_get_contents('/var/www/data/careers.json');
    $careers = json_decode($json, true);
?>