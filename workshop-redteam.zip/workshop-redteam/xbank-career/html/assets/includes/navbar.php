<nav class="navbar navbar-expand-lg navbar-dark mb-4">
<div class="container">
<a class="navbar-brand display-5 text-uppercase" href="/">XBank</a>
</div>
</nav>