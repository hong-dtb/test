<!DOCTYPE html>
<html lang="vi" style="height: 100%;">
<head>
<meta charset="UTF-8">
<link rel="icon" type="image/x-icon" href="/assets/favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
<title><?= TITLE . " - Ngân hàng XBank" ?></title>
<style>
    body {
        display: flex;
        flex-direction: column;
        height: 100%;
    }
    .content {
            flex: 1 0 auto;
        }
    .footer {
        flex-shrink: 0;
    }
    .navbar, .btn-primary, .footer {
        background-color: #007bff;
    }
</style>
</head>