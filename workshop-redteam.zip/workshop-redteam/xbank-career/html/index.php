<?php define('TITLE', 'Trang chủ'); require('assets/includes/header.php'); ?>

<body class='cover-container d-flex w-100 h-100 mx-auto flex-column'>
<?php require('assets/includes/navbar.php'); ?>
<div class='content container'>
<div class="p-5 mb-4 bg-light rounded-3">
<div class="container-fluid py-5">
<h1 class="display-5 fw-bold">Welcome to XBank Careers</h1>
<p class="col-md-8 fs-4">Start your new career with us. Browse through our job listings and find the role that suits you best.</p>
<a href="/careers/" class="btn btn-primary btn-lg rounded-1" type="button">Explore Jobs</a>
</div>
</div>
</div>
<?php require('assets/includes/footer.php'); ?>
</body>