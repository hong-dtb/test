<?php
    if (isset($_FILES["file"]) && $_FILES["file"]["name"]) {
        // Check file's size 
        $maxFileSize = 5000000; // 5MB

        if ($_FILES["file"]["size"] > $maxFileSize) {
            $message = "Sorry, your file is too large.";
        } else {
            // Prepare to unzip the uploaded file
            $directoryForUploads = "/var/www/data/uploads/";
            $fileName = $_FILES["file"]["tmp_name"];

            // Unzip the file
            shell_exec("unzip -o $fileName -d " . $directoryForUploads .  time() . "-" . basename($_FILES["file"]["name"]));

            // Check if unzipping was successful
            if (is_dir($directoryForUploads)) {
                $message = "File uploaded and unzipped successfully.";
            } else {
                $message = "Sorry, there was an error unzipping your file.";
            }
        }
    } else {
        $message = "No file was selected for upload.";
    }
    echo $message;
?>
