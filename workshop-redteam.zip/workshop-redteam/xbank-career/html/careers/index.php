<?php define("TITLE", "Tuyển dụng"); require("../assets/includes/header.php"); ?>

<body>
<?php require("../assets/includes/navbar.php"); ?>
<div class="container">
    <?php require("../assets/includes/database.php"); 
        foreach ($careers as $key => $job) {
            echo '<div class="card mb-4">';
            echo '<div class="card-body">';
            echo '<h5 class="card-title">' . $job['Vị trí tuyển dụng'] . '</h5>';
            echo '<h6 class="card-subtitle mt-2 text-muted">' . $job['Địa điểm'] . '</h6>';
            echo '<p class="card-text">' . $job['description'] . '</p>';
            echo '<a href="job-detail.php?id='. $key .'" class="btn btn-primary rounded-1">Apply Now</a>';
            echo '</div>';
            echo '</div>';
        }?>
</div>
<?php require("../assets/includes/footer.php"); ?>
</body>