<?php
    require("../assets/includes/database.php");

    // Process the GET request
    if (isset($_GET["id"]) && is_numeric($_GET["id"])) {
        $jobId = $_GET["id"];$job = $careers[$jobId];
    } else {
        exit(header("Location: /careers/"));
    }
?>

<?php  define("TITLE", $career['Vị trí tuyển dụng']);require("../assets/includes/header.php"); ?>
<body>
<?php require("../assets/includes/navbar.php"); ?>
<div class="content container">
<h1 class="display-4"><?= $job['Vị trí tuyển dụng'] ?></h1>
<button type="button" class="btn btn-primary my-3 py-2 px-4 text-uppercase rounded-1" data-bs-toggle="modal" data-bs-target="#cvModal">Nộp CV Ngay</button><table class='table lead'>
<tbody>
<tr><td></td><td width="80%"></td></tr>
<tr><td>Khối / Ban</td><td><?= $job['Khối / Ban'] ?></td></tr>
<tr><td>Lĩnh vực</td><td><?= $job['Lĩnh vực'] ?></td></tr>
<tr><td>Địa điểm</td><td><?= $job['Địa điểm'] ?></td></tr>
<tr><td>Loại hình công việc</td><td><?= $job['Loại hình công việc'] ?></td></tr>
<tr><td>Số lượng cần tuyển</td><td><?= $job['Số lượng'] ?></td></tr>
<tr><td>Mô tả</td><td><?= str_replace('.', '</br></br>', $job['Mô tả công việc']) ?></td></tr>
</tbody>
</table>
</div>

<!-- Modal -->
<div class="modal fade" id="cvModal" tabindex="-1" aria-labelledby="cvModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="cvModalLabel">Submit Your CV</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form id="cvForm" action="/upload.php" method="post" enctype="multipart/form-data">
<div class="mb-3">
<label for="cv" class="form-label">Upload your CV (ZIP files only):</label>
<input type="file" class="form-control" id="file" name="file" accept=".zip">
</div>
<button type="submit" class="btn btn-primary rounded-1">Submit Application</button>
</form></div></div></div></div>

<?php require("../assets/includes/footer.php"); ?>
<script>
    document.getElementById('cvForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);

        fetch(this.action, {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(result => {
            alert(result);
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
</script>
</body>
